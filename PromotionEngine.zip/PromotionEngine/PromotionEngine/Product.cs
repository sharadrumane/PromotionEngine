﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PromotionEngine
{
    public class Product
    {
        public string Id { get; set; }
        public decimal Price { get; set; }
        public int Value { get; set; }
    }
}
